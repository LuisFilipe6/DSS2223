
/**
 * Write a description of interface Hibrido here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Hibrido
{
    public int getPotenciaMotorEletrico();
    public void setPotenciaMotorEletrico(int potencia);
}
